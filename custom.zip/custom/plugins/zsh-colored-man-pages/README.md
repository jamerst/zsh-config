# zsh colored man pages
zsh plugin that colorifies man pages.

Bold and blink text are blue while underlined text is green.
