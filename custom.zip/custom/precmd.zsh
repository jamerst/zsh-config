# check current directory and switch to bash when in joshua - speed issues otherwise due to ssh connection being too slow for plugins 
# precmd() {
# 	if [[ $PWD/ = /home/jtattersall/joshua* ]]; then
#     exec bash
#   fi
# }